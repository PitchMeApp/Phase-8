import 'package:flutter/material.dart';

class comingSoon extends StatelessWidget {
  const comingSoon({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
    );
  }
}
