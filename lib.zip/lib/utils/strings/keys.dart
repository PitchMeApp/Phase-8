class Keys {
  static String TOKEN = "TOKEN";
  static String USER_TYPE = "USER_TYPE";

  //dev
  static const googleApiKey = 'AIzaSyAD3hGnODUofmj5qGuDve70CA5_FP3MC_o';
}
