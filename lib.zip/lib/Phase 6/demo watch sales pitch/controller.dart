import 'package:get/get.dart';

class DemoWatchSalesPitchController extends GetxController {
  RxBool isMenuCheck = false.obs;
}
