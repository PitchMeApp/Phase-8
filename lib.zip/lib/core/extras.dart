import 'package:get_storage/get_storage.dart';

GetStorage pref = GetStorage();
