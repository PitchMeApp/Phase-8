class Keys {
  static String TOKEN = "TOKEN";
  static String USER_TYPE = "USER_TYPE";

  //dev
  static const googleApiKey = 'AIzaSyBRCimsPWWDfUqRgW8Y29_iVdJ4ogrtpvk';
}
