import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pitch_me_app/utils/colors/colors.dart';

// Widget banner(){
//   return Align(
//     alignment: Alignment.bottomCenter,
//     child: Container(
//       width: Get.width,
//       height: Get.height * 0.065,
//       alignment: Alignment.bottomCenter,
//       color: colors.bannerColor,
//       child: Center(
//         child: Text(
//           'Banner',
//           style: TextStyle(color: colors.white, fontSize: 16),
//         ),
//       ),
//     ),
//   );
// }