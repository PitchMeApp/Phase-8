import 'package:flutter/material.dart';
import 'package:get/get.dart';

class VideoFirstPageController extends GetxController {
  final TextEditingController editingController = TextEditingController();
  RxString videoUrl = ''.obs;
}
